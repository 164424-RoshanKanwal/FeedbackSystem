package com.cfs.adminpanel.models;


public class FeedbackRatings {

	
	private String titleOfTraining;
	private String trainerName;
	private double ratings;
	
	public FeedbackRatings() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FeedbackRatings(String titleOfTraining, String trainerName, double ratings) {
		super();
		this.titleOfTraining = titleOfTraining;
		this.trainerName = trainerName;
		this.ratings = ratings;
	}
	public String getTitleOfTraining() {
		return titleOfTraining;
	}
	public void setTitleOfTraining(String titleOfTraining) {
		this.titleOfTraining = titleOfTraining;
	}
	public String getTrainerName() {
		return trainerName;
	}
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	public double getRatings() {
		return ratings;
	}
	public void setRatings(double ratings) {
		this.ratings = ratings;
	}
	@Override
	public String toString() {
		return "FeedbackRatings [titleOfTraining=" + titleOfTraining + ", trainerName=" + trainerName + ", ratings="
				+ ratings + "]";
	}
	
		
	
}
