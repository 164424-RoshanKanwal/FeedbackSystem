package com.cfs.adminpanel.models;



import java.util.Date;

public class Feedback {

	private String formId;
	
	private String titleOfTraining;
	private String trainerName;
	private Date startDate;
	private Date endDate;
	private int daysSurveyAvailable;
	private String question1;
	private String question2;
	private String question3;
	private String question4;
	private String question5;
	
//	String pattern = "dd MMMMM yyyy";
//	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//	

	
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	
	public String getQuestion1() {
		return question1;
	}




	public void setQuestion1(String question1) {
		this.question1 = question1;
	}




	public String getQuestion2() {
		return question2;
	}




	public void setQuestion2(String question2) {
		this.question2 = question2;
	}




	public String getQuestion3() {
		return question3;
	}




	public void setQuestion3(String question3) {
		this.question3 = question3;
	}




	public String getQuestion4() {
		return question4;
	}




	public void setQuestion4(String question4) {
		this.question4 = question4;
	}




	public String getQuestion5() {
		return question5;
	}




	public void setQuestion5(String question5) {
		this.question5 = question5;
	}




	public Feedback(String formId, String titleOfTraining, String trainerName, Date startDate, Date endDate,
		int daysSurveyAvailable, String question1, String question2, String question3, String question4,
		String question5) {
	super();
	this.formId = formId;
	this.titleOfTraining = titleOfTraining;
	this.trainerName = trainerName;
	this.startDate = startDate;
	this.endDate = endDate;
	this.daysSurveyAvailable = daysSurveyAvailable;
	this.question1 = question1;
	this.question2 = question2;
	this.question3 = question3;
	this.question4 = question4;
	this.question5 = question5;
}




	@SuppressWarnings("deprecation")
	public String getFormId() {
		formId = titleOfTraining + "-" + ( startDate.getMonth() + 1)  + "-" + startDate.getMonth() + "-" + (startDate.getYear() + 1900);
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getTitleOfTraining() {
		return titleOfTraining;
	}
	
	public void setTitleOfTraining(String titleOfTraining) {
		this.titleOfTraining = titleOfTraining;
	}
	
	public String getTrainerName() {
		return trainerName;
	}
	
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public int getDaysSurveyAvailable() {
		return daysSurveyAvailable;
	}
	
	public void setDaysSurveyAvailable(int daysSurveyAvailable) {
		this.daysSurveyAvailable = daysSurveyAvailable;
	}
	

	
	
}
