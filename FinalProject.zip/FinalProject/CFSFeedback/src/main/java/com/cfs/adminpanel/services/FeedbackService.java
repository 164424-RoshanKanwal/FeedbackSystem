package com.cfs.adminpanel.services;



import java.util.List;

import com.cfs.adminpanel.models.EmployeeFeedback;
import com.cfs.adminpanel.models.Feedback;
import com.cfs.adminpanel.models.FeedbackRatings;
import com.cfs.adminpanel.models.Response;

public interface FeedbackService {

	Response<String> addSurvey(Feedback feedback);
	Response<Feedback> previewOfSurvey(String formId);
	Response<Feedback> updateFeedback(Feedback modifiedFeedback);
	Response<Boolean> deleteFeedback(String id);
	Response<List<Feedback>> getFeedbacks();
	Response<Boolean> submitFeedback(EmployeeFeedback employeeFeedback);
	public List<FeedbackRatings> getAllFeedbackRating();
}
