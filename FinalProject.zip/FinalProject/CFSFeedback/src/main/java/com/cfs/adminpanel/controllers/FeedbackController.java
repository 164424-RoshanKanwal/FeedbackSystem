package com.cfs.adminpanel.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cfs.adminpanel.models.EmployeeFeedback;
import com.cfs.adminpanel.models.Feedback;
import com.cfs.adminpanel.models.FeedbackRatings;
import com.cfs.adminpanel.models.Response;
import com.cfs.adminpanel.services.FeedbackService;

@RestController
public class FeedbackController {

	@Autowired
	private FeedbackService feedbackService;
	
	
	@GetMapping("/")
	public Response<List<Feedback>> allSurveys(){
		return feedbackService.getFeedbacks();
	}

	@GetMapping("/{formId}")
	public Response<Feedback> getSurvey(@PathVariable String formId) {
		
		System.out.println(formId);
		return feedbackService.previewOfSurvey(formId);
		
	}
	
	@PostMapping("/")
	public Response<String> addSurvey(@RequestBody Feedback feedback) {
		
		return feedbackService.addSurvey(feedback);
		
	}
	
	@PostMapping("/employee")
	public Response<Boolean> submitFeedback(@RequestBody EmployeeFeedback employeeFeedback) {
		
		return feedbackService.submitFeedback(employeeFeedback);
	}
	
	
	
	@PutMapping("/")
	public Response<Feedback> updateFeedback(Feedback modifiedFeedback){
		return feedbackService.updateFeedback(modifiedFeedback);
	}
	
	@DeleteMapping("/{id}")
	public Response<Boolean> deleteSurvey(@PathVariable String id){
		return feedbackService.deleteFeedback(id);
	}
	
	
	@GetMapping("/home")
	public Response<List<FeedbackRatings>> getAllFeedbackRatings(){
		return new Response<>(feedbackService.getAllFeedbackRating(),HttpStatus.OK.value(), "success");
	}
	
}
