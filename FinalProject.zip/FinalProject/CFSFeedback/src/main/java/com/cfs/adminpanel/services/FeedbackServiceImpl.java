package com.cfs.adminpanel.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cfs.adminpanel.models.EmployeeFeedback;
import com.cfs.adminpanel.models.Feedback;
import com.cfs.adminpanel.models.FeedbackRatings;
import com.cfs.adminpanel.models.Response;

@Service
@SuppressWarnings("unchecked")
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	RestTemplate restTemplate;
	
	private final String baseURL = "http://localhost:2100/";
	
	
	@Override
	public Response<List<Feedback>> getFeedbacks() {
		
		return restTemplate.getForEntity(baseURL + "/feedback", Response.class).getBody();
	}
	
	@Override
	public Response<String> addSurvey(Feedback feedback) {
		
		return restTemplate.postForObject(baseURL + "/feedback", feedback, Response.class);
		
	}
	
	
	@Override
	public Response<Feedback> previewOfSurvey(String formId) {
		
		return restTemplate.getForObject(baseURL + "/feedback/{formId}" , Response.class, formId);
	}

	@Override
	public Response<Boolean> submitFeedback(EmployeeFeedback employeeFeedback) {
		
		return restTemplate.postForObject(baseURL + "/feedback/employee", employeeFeedback, Response.class);
	}
	
	@Override
	public Response<Feedback> updateFeedback(Feedback modifiedFeedback) {
		
		 restTemplate.put(baseURL + "/feedback/" , Feedback.class);
		
		 //future implementation
		 
		 return null;
	}

	@Override
	public Response<Boolean> deleteFeedback(String id) {
		
		 restTemplate.delete(baseURL + "{id}");
		//future implementation
		 return null;
	}

	
	public List<FeedbackRatings> getAllFeedbackRating() {
		
		HashMap<String, FeedbackRatings> hashmap= new HashMap<String, FeedbackRatings>();
		
		List<EmployeeFeedback> list = restTemplate.getForEntity(baseURL + "/feedback/employee", List.class).getBody();
		
		for (EmployeeFeedback employeeFeedback : list) {
			
			if(!hashmap.containsKey(employeeFeedback.getFormId())) {
				
				Response<Feedback> response = restTemplate.getForObject(baseURL + "/feedback/{formId}", Response.class, employeeFeedback.getFormId());
				
				FeedbackRatings feedbackRatings = new FeedbackRatings();
				Feedback feedback = (Feedback) response.getObject();
				
				feedbackRatings.setTitleOfTraining(feedback.getTitleOfTraining());
				feedbackRatings.setTrainerName(feedback.getTrainerName());
				feedbackRatings.setRatings(employeeFeedback.getRatings());
				
				hashmap.put(employeeFeedback.getFormId(),feedbackRatings);
			}
			
			
		}
		
		
		return new ArrayList<FeedbackRatings>(hashmap.values());
		
	}

	

}
