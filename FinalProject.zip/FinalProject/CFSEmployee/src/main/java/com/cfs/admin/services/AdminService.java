package com.cfs.admin.services;

import org.springframework.http.ResponseEntity;

import com.cfs.admin.models.EmployeeResponse;
import com.cfs.admin.models.LoginCredentials;

public interface AdminService {//this interface can be used for future enhancement
	ResponseEntity<EmployeeResponse> validate(LoginCredentials loginCredentials);
	
}
