package com.cfs.admin.services;

import org.springframework.http.ResponseEntity;

import com.cfs.admin.models.Employee;
import com.cfs.admin.models.EmployeeResponse;
import com.cfs.admin.models.ForgotPasswordCredentials;
import com.cfs.admin.models.LoginCredentials;

public interface EmployeeService {

	ResponseEntity<EmployeeResponse> validate(LoginCredentials loginCredentials);
	ResponseEntity<EmployeeResponse> register(Employee employee);
	String forgotPassword(ForgotPasswordCredentials forgotPasswordCredentials);
	
}
  