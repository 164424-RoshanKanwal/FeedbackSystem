package com.cfs.admin.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cfs.admin.models.Employee;
import com.cfs.admin.models.EmployeeResponse;
import com.cfs.admin.models.ForgotPasswordCredentials;
import com.cfs.admin.models.LoginCredentials;


@Service
public class EmployeeServiceImpl implements EmployeeService, AdminService{

	@Autowired
	private RestTemplate restTemplate;
	
	 Employee employee;
	
	private HttpHeaders responseHeaders = new HttpHeaders();
	

	final String baseURL = "http://localhost:2101/employee";
	
	@Override
	public ResponseEntity<EmployeeResponse> validate(LoginCredentials loginCredentials) {
		
		EmployeeResponse employeeResponse = restTemplate.postForEntity(baseURL + "/{empId}",loginCredentials, EmployeeResponse.class, loginCredentials.getEmpId()).getBody();
		Employee employee = employeeResponse.getEmployee();
		
		if(employee == null) {
			
			return new ResponseEntity<EmployeeResponse>(employeeResponse ,HttpStatus.OK);
			
		}
		
		else if(employee.getempId() == loginCredentials.getEmpId() && employee.getPassword().equals(loginCredentials.getPassword()) && employee.getRole().equals(loginCredentials.getRole())) {
			
			responseHeaders.set("message", "Successful Login");
			employeeResponse.setMessage("Successful Login");
			return new ResponseEntity<EmployeeResponse>(employeeResponse, responseHeaders ,HttpStatus.OK);
		
		}
		
		else {
		responseHeaders.set("message", "Invalid username or password");
		return new ResponseEntity<EmployeeResponse>( new EmployeeResponse(HttpStatus.NOT_FOUND.value(), "Invalid username or password", null), responseHeaders ,HttpStatus.OK);
	}
	}
	
	
	@Override
	public ResponseEntity<EmployeeResponse> register(Employee newEmployee) {
		
		return restTemplate.postForEntity(baseURL, newEmployee, EmployeeResponse.class);
		
	}

	
	@Override
	public String forgotPassword(ForgotPasswordCredentials forgotPasswordCredentials) {
		System.out.println("Undar update service");
		
		restTemplate.put(baseURL + "/{empId}",forgotPasswordCredentials, forgotPasswordCredentials.getEmpId());
		
		return "Updated";
				}


}
