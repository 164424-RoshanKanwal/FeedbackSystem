package com.cfs.admin.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cfs.admin.models.Employee;
import com.cfs.admin.models.EmployeeResponse;
import com.cfs.admin.models.ForgotPasswordCredentials;
import com.cfs.admin.models.LoginCredentials;
import com.cfs.admin.services.EmployeeService;

@CrossOrigin("*")
@RestController
public class EmployeeController {
	
	@Autowired 
	EmployeeService employeeService;
	
	
	@PostMapping("/login")
	public ResponseEntity<EmployeeResponse> validateEmployee(@RequestBody LoginCredentials loginCredentials) {
		
		return employeeService.validate(loginCredentials);
	
	}
	
	
	
	
	@PostMapping("/register")
	public ResponseEntity<EmployeeResponse> registerEmployee(@RequestBody Employee newEmployee) {
		
		return employeeService.register(newEmployee);
		
	}
	
	
	
	@PutMapping("/forgot-password")
	public String updateEmployee(@RequestBody ForgotPasswordCredentials forgotPasswordCredentials) {
		System.out.println("Undar update");
	 
		return employeeService.forgotPassword(forgotPasswordCredentials);
	 
	}
}
