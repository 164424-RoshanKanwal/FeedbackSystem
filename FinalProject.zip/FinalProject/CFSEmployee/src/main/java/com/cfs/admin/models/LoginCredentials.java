package com.cfs.admin.models;

public class LoginCredentials {

	
	private long empId;
	private String password;
	private String role;
	public LoginCredentials() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginCredentials(long empId, String password
			, String role) {
		super();
		this.empId = empId;
		this.role= role;
		this.password = password;
	}
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "LoginCredentials [empId=" + empId + ", password=" + password + "]";
	}
	
	
	
}
