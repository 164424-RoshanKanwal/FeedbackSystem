package com.cfs.adminpaneldata.models;

public class FeedbackPreview {

	private Feedback panelAttributes;
	private int ratings;
	private String suggestions;
	public FeedbackPreview() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FeedbackPreview(Feedback panelAttributes, int ratings, String suggestions) {
		super();
		this.panelAttributes = panelAttributes;
		this.ratings = ratings;
		this.suggestions = suggestions;
	}
	public Feedback getPanelAttributes() {
		return panelAttributes;
	}
	public void setPanelAttributes(Feedback panelAttributes) {
		this.panelAttributes = panelAttributes;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	@Override
	public String toString() {
		return "PanelPreviewAttributes [panelAttributes=" + panelAttributes + ", ratings=" + ratings + ", suggestions="
				+ suggestions + "]";
	}
	
	
	
	
}
