package com.cfs.adminpaneldata.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cfs.adminpaneldata.models.Feedback;
import com.cfs.adminpaneldata.models.Response;

@ControllerAdvice
public class ControllerErrorHandler {

	@ExceptionHandler(FeedbackNotFoundException.class)
	public Response<Feedback> handleFeedbackNotFoundException(FeedbackNotFoundException exception){
		
		return new Response<Feedback>(null, HttpStatus.NOT_FOUND.value(), exception.getMessage());
	}
	
	

	
	@ExceptionHandler(FeedbackAlreadyAvailableException.class)
	public Response<String> handleFeedbackAlreadyAvailableException(FeedbackAlreadyAvailableException exception){	
		return new Response<String>("A feedback already exists by this name of this date", HttpStatus.BAD_REQUEST.value(), exception.getMessage());
	}
	
	
	@ExceptionHandler(FeedbackDatabaseException.class)
	public Response<Feedback> handleFeedbackDatabaseException(FeedbackDatabaseException exception){
		
		return new Response<Feedback>(null, HttpStatus.BAD_REQUEST.value(), exception.getMessage());
	}
}
