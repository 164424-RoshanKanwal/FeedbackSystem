package com.cfs.adminpaneldata.models;



import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="EmployeeFeedback")
public class EmployeeFeedback {

//	private long empId;
//	private String formId;
//	private List<QuestionAnswer> questionAnswer;
//	private int ratings;
//	
//	//private String suggestions
//	
//	public EmployeeFeedback() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	
//	public EmployeeFeedback(long empId, String formId, List<QuestionAnswer> questionAnswer, int ratings) {
//		super();
//		this.ratings=ratings;
//		this.empId = empId;
//		this.formId = formId;
//		this.questionAnswer = questionAnswer;
//	}
//	
//	
//	
//	public int getRatings() {
//		return ratings;
//	}
//
//	public void setRatings(int ratings) {
//		this.ratings = ratings;
//	}
//
//	public long getEmpId() {
//		return empId;
//	}
//	public void setEmpId(long empId) {
//		this.empId = empId;
//	}
//	public String getFormId() {
//		return formId;
//	}
//	public void setFormId(String formId) {
//		this.formId = formId;
//	}
//	public List<QuestionAnswer> getQuestionAnswer() {
//		return questionAnswer;
//	}
//	public void setQuestionAnswer(List<QuestionAnswer> questionAnswer) {
//		this.questionAnswer = questionAnswer;
//	}
//	
//	@Override
//	public String toString() {
//		return "EmployeeFeedback [empId=" + empId + ", formId=" + formId + ", questionAnswer=" + questionAnswer + "]";
//	}
//	
	
	private long empId;
	private String formId;
	private String question1;
	private String question2;
	private String question3;
	private String question4;
	private String question5;
	private String answer1;
	private String answer2;
	private String answer3;
	private String answer4;
	private String answer5;
	private double ratings;
	public EmployeeFeedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeFeedback(long empId, String formId, String question1, String question2, String question3,
			String question4, String question5, String answer1, String answer2, String answer3, String answer4,
			String answer5, double ratings) {
		super();
		this.empId = empId;
		this.formId = formId;
		this.question1 = question1;
		this.question2 = question2;
		this.question3 = question3;
		this.question4 = question4;
		this.question5 = question5;
		this.answer1 = answer1;
		this.answer2 = answer2;
		this.answer3 = answer3;
		this.answer4 = answer4;
		this.answer5 = answer5;
		this.ratings = ratings;
	}
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getQuestion1() {
		return question1;
	}
	public void setQuestion1(String question1) {
		this.question1 = question1;
	}
	public String getQuestion2() {
		return question2;
	}
	public void setQuestion2(String question2) {
		this.question2 = question2;
	}
	public String getQuestion3() {
		return question3;
	}
	public void setQuestion3(String question3) {
		this.question3 = question3;
	}
	public String getQuestion4() {
		return question4;
	}
	public void setQuestion4(String question4) {
		this.question4 = question4;
	}
	public String getQuestion5() {
		return question5;
	}
	public void setQuestion5(String question5) {
		this.question5 = question5;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	public String getAnswer4() {
		return answer4;
	}
	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}
	public String getAnswer5() {
		return answer5;
	}
	public void setAnswer5(String answer5) {
		this.answer5 = answer5;
	}
	public double getRatings() {
		return ratings;
	}
	public void setRatings(double ratings) {
		this.ratings = ratings;
	}
	@Override
	public String toString() {
		return "EmployeeFeedback [empId=" + empId + ", formId=" + formId + ", question1=" + question1 + ", question2="
				+ question2 + ", question3=" + question3 + ", question4=" + question4 + ", question5=" + question5
				+ ", answer1=" + answer1 + ", answer2=" + answer2 + ", answer3=" + answer3 + ", answer4=" + answer4
				+ ", answer5=" + answer5 + ", ratings=" + ratings + "]";
	}
	
	
	
	
}
