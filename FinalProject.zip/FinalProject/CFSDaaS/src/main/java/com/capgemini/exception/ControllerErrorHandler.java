package com.capgemini.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.model.Employee;
import com.capgemini.model.EmployeeResponse;

@ControllerAdvice
public class ControllerErrorHandler {

	HttpHeaders responseHeaders = new HttpHeaders();
	
	@ExceptionHandler(EmployeeNotExistException.class)
	public ResponseEntity<EmployeeResponse> handleUserNotExistException(EmployeeNotExistException exception) {

		responseHeaders.set("message", exception.getMessage());
		EmployeeResponse employeeResponse = new EmployeeResponse(HttpStatus.NOT_FOUND.value(), exception.getMessage(),new Employee());
		return new ResponseEntity<>(employeeResponse, responseHeaders, HttpStatus.OK);
	}
	

	@ExceptionHandler(AlreadyEmployeeExistException.class)
	public ResponseEntity<EmployeeResponse> handleAlreadyUserExistException(AlreadyEmployeeExistException exception) {

		responseHeaders.set("message","Employee Already Registered");
		return new ResponseEntity<>(new EmployeeResponse(HttpStatus.BAD_REQUEST.value(), exception.getMessage() ,new Employee()), responseHeaders, HttpStatus.OK);
}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Employee> handleAllExceptions(Exception exception) {
		
		responseHeaders.set("message", exception.getMessage());
		Employee employee=null;
		return new ResponseEntity<>(employee, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

	}
}
