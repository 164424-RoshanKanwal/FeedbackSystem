package com.capgemini.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.AlreadyEmployeeExistException;
import com.capgemini.exception.EmployeeNotExistException;
import com.capgemini.model.Employee;
import com.capgemini.model.EmployeeResponse;
import com.capgemini.model.ForgotPasswordCredentials;
import com.capgemini.model.LoginCredentials;


@RestController
public class EmployeeController {
	
	
	@Autowired
	private MongoTemplate mongoTemplate;

	HttpHeaders responseHeaders = new HttpHeaders();
	
	
	//returns employee object from employee collection that matches the id
	
	@PostMapping("/employee/{empId}")
	public ResponseEntity<EmployeeResponse> getUserById(@PathVariable long empId, @RequestBody LoginCredentials loginCredentials) {
		
		Employee employee = mongoTemplate.findById(empId, Employee.class);
		
		if(employee == null) {
			throw new EmployeeNotExistException("Employee Does Not Exist");
		}
		
		else {
			responseHeaders.set("message","Success");
			EmployeeResponse employeeResponse = new EmployeeResponse(HttpStatus.OK.value(), "Success",employee);
			return new ResponseEntity<>(employeeResponse, responseHeaders, HttpStatus.OK);
			}

	}

	
	
	
	//save the provided employee object in employee collection and returns same object back
	@PostMapping("/employee")
	public ResponseEntity<EmployeeResponse> saveEmployee(@RequestBody Employee newEmployee) {
		
		Employee employee = mongoTemplate.findById(newEmployee.getEmpId(), Employee.class);
		
		if(employee!=null) {
			throw new AlreadyEmployeeExistException("Employee Already Registered");
		}
		
		mongoTemplate.save(newEmployee);
		responseHeaders.set("message","Successfully Registered");
		return new ResponseEntity<EmployeeResponse>(new EmployeeResponse(HttpStatus.OK.value(), "Successfully Registered", employee), HttpStatus.OK);
	
		}
	
	
	
	
	//forgot password
	//FUTURE IMPLEMENTATION UNDER PROGRESS..
	@PutMapping("/employee/{empId}")
	public String updateEmployee(@PathVariable long empId, @RequestBody ForgotPasswordCredentials forgotPasswordCredentials){
		
		Employee employee = mongoTemplate.findById(empId, Employee.class);
		if(employee == null) {
			throw new EmployeeNotExistException("No Employee is registered with this employee id.");
		}
		
		else if (forgotPasswordCredentials.getEmail().equals(employee.getEmail()) && forgotPasswordCredentials.getContact()==employee.getContact()) {
			
			employee.setPassword(forgotPasswordCredentials.getPassword());
			mongoTemplate.save(employee);
			return "Updated";
			//return new ResponseEntity<EmployeeResponse>(new EmployeeResponse(HttpStatus.OK.value(), "Successfully Updated", employee), HttpStatus.OK);
			
		}
		else {
			
			responseHeaders.set("message","Invalid username or password");
			//Employee emp = new Employee();
			return "Not Updated";
			//return new ResponseEntity<>(new EmployeeResponse(HttpStatus.NOT_FOUND.value(), "Invalid email or contact number.",emp), responseHeaders, HttpStatus.OK);
			
		}
	}
}

